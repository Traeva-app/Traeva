import sys,json,tempfile,uuid,base64,errno
from pathlib import Path
sys.path.insert(0,sys.argv[1])
import writer
root=Path('/private/tmp/traeva-c-verified-review-fixes')
run=Path(tempfile.mkdtemp(prefix='traeva-c-verified-before-',dir='/private/tmp'))
(run/'app-data').mkdir()
minimal={'receiptKind':'HISTORICAL_ACQUISITION_OBSERVATION','sourceNamespace':'TRAEVA_CHROME_FETCH_ACQUISITION','state':'OBSERVATION_RECORDED'}
(run/'app-data'/'empty.receipt.json').write_text(json.dumps(minimal))
results=[{'finding':'B1','required':'reject incomplete receipt','actual':writer.inspect_restart(run),'result':'FAIL_ORIGINAL'}]
for case in ('post_commit_event','privacy_header'):
 run=Path(tempfile.mkdtemp(prefix='traeva-c-verified-before-',dir='/private/tmp'))
 lab=writer.Writer(run,['https://fixture.invalid']);lab.authorize({'takeoverConsent':True,'saveLocationConsent':str(lab.delivery)})
 aid=str(uuid.uuid4());body=b'synthetic'
 lab.begin({'acquisitionId':aid,'destination':'example.txt','scenario':case,'binding':{'tabId':1,'fetchRequestId':'request','stream':'stream'},'response':{'url':'https://fixture.invalid/file','status':200,'headers':[{'name':'Content-Length','value':str(len(body))},{'name':'Set-Cookie','value':'SYNTHETIC_PRIVATE_COOKIE'}]}})
 lab.chunk({'acquisitionId':aid,'sequence':0,'base64':base64.b64encode(body).decode()})
 if case=='post_commit_event':
  event=lab.event
  def fault(kind,data):
   if kind=='acquisition_observation_saved':raise OSError(errno.EIO,'synthetic event EIO')
   return event(kind,data)
  lab.event=fault
 error=None
 try:outcome=lab.complete({'acquisitionId':aid,'eof':True})
 except Exception as e:outcome=None;error=type(e).__name__
 receipt=lab.app_data/(aid+'.receipt.json')
 results.append({'finding':'B2' if case=='post_commit_event' else 'B4','result':'FAIL_ORIGINAL','completeReply':outcome is not None,'error':error,'liveState':lab.tasks[aid].record['state'],'receiptPresent':receipt.exists(),'restart':writer.inspect_restart(run),'sensitiveHeaderPersisted':'SYNTHETIC_PRIVATE_COOKIE' in receipt.read_text()})
 lab.close()
(root/'before-writer.json').write_text(json.dumps({'sourceHead':'dcbf13317ea729b177b7d92a502ddadc501fe445','cases':results},indent=2))
print(json.dumps(results))
