# PR #102 审核修复与最小接入方案

**结论：限定实验修复可交 R1 定向复验；正式产品 VERIFIED 仍 NO-GO。**
本轮没有修改已验收的 #27、共享核心/契约/权限、A/B Memory 或 #37，没有 merge。

基线 main：6f14e3a7dbdb9b60f2d7945054fc1d8556f8ccdf。
原实验/R1 审核：dcbf13317ea729b177b7d92a502ddadc501fe445，PR #102。
最终修复源码按新证据包 environment.codeRevision 和 source 文件 hash 固定；PR 最新 head
还包含独立的证据提交。原 REPORT.txt / source-verified-evidence.zip 不覆盖。

| 项目 | 原始 FAIL（保留） | 修复与验证 |
|---|---|---|
| B1 | 三字段 JSON 被当成历史获取成功 | v1 收据严格校验全部必需字段、类型/范围、namespace/完整 binding、文件名/ID、创建与最终目标身份、hash、时间及历史标记。缺字段、null、bool、错误身份/绑定/版本均拒绝；重复 JSON key、symlink、FIFO 也拒绝。旧无版本收据不自动升级。 |
| B2 | receipt 提交后日志 EIO 导致 live 确定失败，重启却读到成功 | 文件 fsync + replace + app-data 目录 fsync 为收据提交点。提交后的事件写入/fsync/状态保存故障只附告警，保留历史成功。replace 可见但目录持久化未获确认则 OUTCOME_UNKNOWN；回复丢失也为 UNKNOWN，不 abort/重下载/删除收据。 |
| B3 | 大小写支持判断通过，取流后 filename 解析失败 | 单一解析器在取流前产生 response、filename、完整 destination；长度上限、参数大小写、扩展名、字段类型、响应格式及 Native prepare 全部先检查。已有目标先拒绝；后续竞争仍由独占创建拒绝。 |
| B4 | POST、Cookie、Authorization、正文和 query 留在事件/缓存，Set-Cookie 留在收据 | 不缓存完整事件；最小事件白名单、响应头白名单、固定错误码；不全量检索浏览器历史。实验只支持无凭据/query/fragment 的合成 URL；固定运行的内存、持久记录及归档扫描均无敏感哨兵值。 |

R1 的独立原 FAIL 归档保持原 SHA：
`d1ff9c355755859bf35f404caa1fbd6bab337e3a6639a469d2a6d9d19b915ca3`。
C 原 #102 归档仍为 `043334e6dfd6fa944c1c72d30eae5c7fa259eaec3f71cdfbf42f9f67acd0c2d0`。
本轮自行复现的 before-writer / before-worker 与原源码也单独保留，不把原 FAIL 改成 PASS。

## 实测范围

- 31 项 Python 测试通过，含原 22 项和新增收据/提交/隐私/配额反例。多字段篡改以
  subtests 展开，不把每个变体虚增为独立功能验收。真实 Native 子进程在收据提交后
  `os._exit(74)` 丢失回复；新进程只承认严格历史收据，不恢复活句柄。
- 37 个实际 worker 源码 VM 场景通过。CDP/Native 回复为模拟，包括文件名有效/拒绝
  边界、Native 拒绝、提交不确定/回复丢失、epoch 变化、同标签重叠任务、隐私和配额。
  这些不算真实 Chrome 验收。
- 最终源码在独立、有窗口真实 Chrome 上完成 8 个定向下载场景（另有 2 个授权检查）：
  normal、uppercase、too-long、private-query、redirect、stage-swap、debugger-detach、http。
  成功 5 条获取收据；超长/query/HTTP 均由 Chrome 正常完成；调试断开为明确失败且
  无收据。并发交换临时路径仍交付各自正确字节与新目标对象。157 项记录/文件/
  属性/隐私一致性核对通过。不是 157 项独立安全证明。
- 原直连合成 TLS 方法复跑 5 场景：正常和两项并发交付成功，截断与不支持分块拒绝；
  严格收据读回保留历史。实际网络是生成证书的 localhost TLS，不是公共 CA 验收。
- epoch/native 连接变化使旧 handler 失效。实验最多 4 个活跃任务、32 个生命周期任务、
  80 MiB 总声明接收量；保留至多 64 个任务 FD（另有目录/日志 FD）。浏览器事件最多
  2048 条、元数据缓存 128 条；Native 日志最多 16384 条/32 MiB。预算不足先拒绝。

新证据：`review-fixes-evidence.zip` 和 `review-fixes-sha256.txt`；MANIFEST 固定所有文件。
包含真实合成输出、对象及 xattr 读回、运行记录、源码、前后对照和 R1 原归档。
ZIP 不保留活句柄，也不恢复 xattr，属性记录是历史观察。
隐私扫描只约束修复后的运行输出；测试源码/输入定义以及原 FAIL 档案中有合成哨兵
是必要证据，不据此掩盖真实秘密或修改原 FAIL。

Python syntax 在内存检查通过。一次 py_compile 因系统尝试写 Apple 外部缓存而被沙箱
拒绝，记录为工具环境失败，改用不落盘检查，没有申请放开个人缓存。未运行 Rust/
产品构建/云端测试：所有改动仅在 experiments，不能继承产品或 CI 验收。

## 正式集成仍需解决

完整最小方案见 [INTEGRATION-PROPOSAL.md](INTEGRATION-PROPOSAL.md)，是提案，不是批准的共享接口。
已在 [#65 向 Claude-A 核对](https://github.com/P30g53/Traeva/issues/65#issuecomment-6101837773)：
core 持有目标句柄和一次性 capability、当前 root/接管授权 generation、同事务精确登记与
来源绑定、提交/撤权顺序和对账恢复。尚未收到 A 确认，不能写成已核对通过。

macOS quarantine/WhereFroms 的存在不证明 Chrome Safe Browsing/危险下载判定、Gatekeeper/
XProtect 等保护已经保留；接管取消原 Chrome 下载后，危险判定仍缺可信边界。这仍是
产品启用 blocker。实际 debugger 权限提示/用户取消/DevTools 冲突、正式安装签名与
extension ID、配对轮换/撤权也未验收，默认权限没有改变。

不支持场景在取流前放行；取流后失败必须显示接管失败或不确定，不能声称 Chrome
正常完成，也不静默重下。原 User Confirmed 不升级，不把 acquisition 冒充 Chrome ID。
本实验拒绝 query 只是研究范围，不改变 #27 已批准的本地下载链接存储规则。

公共 CA、真实同标签并发、复杂非 ASCII/二进制、跨域/iframe/worker、登录/POST/blob、
HTTP2/3、跨卷/cloud、真实断电、原子发布和安全残留清理仍未验证。保留原失败证据和
FIRST VERIFIED DEFERRED，不把本轮研究 PASS 计入 #27 产品 VERIFIED PASS。

**10/20 Freeze 风险已提前在 #65 提醒**：核心新写入路径、权限/安装和安全验收可能占用
Memory 收尾时间。建议独立排期，不让 #37 或已 Accepted 的 #27 依赖这项研究；条件未
闭合则冻结时继续关闭。下一步只交 R1 针对新 head 复验 B1–B4，由学生决定正式集成。
