importScripts('config.js');

const events = [], acquisitions = [], sessions = new Map(), paused = new Map(), pending = new Map();
let port, authorized = false, serial = 0;
const record = (event, data = {}) => events.push({at: Date.now(), event, ...data});
const send = (source, method, params = {}) => chrome.debugger.sendCommand(source, method, params);
const key = (source, id) => JSON.stringify([source.tabId, source.sessionId || '', sessions.get(source.tabId)?.epoch, id]);

function disconnected(message) {
  record('native_disconnected', {message}); port = null; authorized = false;
  for (const promise of pending.values()) {clearTimeout(promise.timer); promise.reject(new Error(message));}
  pending.clear();
}

function connect() {
  if (port) return;
  port = chrome.runtime.connectNative('org.traeva.source_verified_lab');
  port.onMessage.addListener(reply => {
    const promise = pending.get(reply.rid);
    if (!promise) return;
    clearTimeout(promise.timer); pending.delete(reply.rid);
    if (reply.ok) promise.resolve(reply);
    else {const error = new Error(reply.error); error.nativeRefusal = true; promise.reject(error);}
  });
  port.onDisconnect.addListener(() => {
    const message = chrome.runtime.lastError?.message || 'native_port_closed';
    disconnected(message);
  });
}

function rpc(command, payload = {}) {
  connect();
  const rid = ++serial;
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => {pending.delete(rid); reject(new Error('native_reply_timeout'));}, 15000);
    pending.set(rid, {resolve, reject, timer});
    try {port.postMessage({rid, auth: LAB.token, command, payload});}
    catch (error) {clearTimeout(timer); pending.delete(rid); reject(error);}
  });
}

function supported(event) {
  const url = new URL(event.request.url);
  if (!authorized || url.protocol !== 'https:' || !LAB.origins.includes(url.origin) || event.request.method !== 'GET') return false;
  const hs = event.responseHeaders || [];
  const values = name => hs.filter(h => h.name.toLowerCase() === name).map(h => h.value.trim());
  const lengths = values('content-length');
  const mime = values('content-type');
  const disposition = values('content-disposition');
  return event.responseStatusCode === 200 && lengths.length === 1 && /^[0-9]+$/.test(lengths[0]) &&
    Number(lengths[0]) > 0 && Number(lengths[0]) <= 20 * 1024 * 1024 &&
    !values('transfer-encoding').length && values('content-encoding').every(x => x.toLowerCase() === 'identity') &&
    mime.length === 1 && /^text\/plain(?:;|$)/i.test(mime[0]) && disposition.length === 1 &&
    /^attachment;\s*filename="[a-zA-Z0-9_-]+\.(?:txt|md)"$/i.test(disposition[0]);
}

async function onPaused(source, event) {
  const config = sessions.get(source.tabId);
  const prior = paused.get(key(source, event.requestId));
  const merged = {...prior, ...event, redirectedRequestId: event.redirectedRequestId || prior?.redirectedRequestId};
  paused.set(key(source, event.requestId), merged);
  record('fetch_paused', {source, scenario: config?.scenario, data: event});
  if (!config || !supported(event)) {
    await send(source, 'Fetch.continueRequest', {requestId: event.requestId});
    record('continued_before_take', {scenario: config?.scenario, requestId: event.requestId, url: event.request.url});
    return;
  }
  const response = {url: event.request.url, status: event.responseStatusCode, headers: event.responseHeaders};
  try {await rpc('prepare', {response});}
  catch (error) {
    await send(source, 'Fetch.continueRequest', {requestId: event.requestId});
    record('continued_before_take', {scenario: config.scenario, requestId: event.requestId, reason: error.message});
    return;
  }
  const chain = []; let current = merged;
  const seen = new Set();
  while (current && !seen.has(current.requestId)) {
    seen.add(current.requestId);
    chain.unshift({requestId: current.requestId, redirectedRequestId: current.redirectedRequestId || null,
      url: current.request.url, status: current.responseStatusCode});
    current = current.redirectedRequestId ? paused.get(key(source, current.redirectedRequestId)) : null;
  }
  const task = {acquisitionId: crypto.randomUUID(), scenario: config.scenario, response, redirectChain: chain,
    state: 'PREPARED', source, browserRequestDisposition: 'PAUSED_NOT_TAKEN'};
  acquisitions.push(task);
  let stream, began = false, completing = false;
  try {
    ({stream} = await send(source, 'Fetch.takeResponseBodyAsStream', {requestId: event.requestId}));
    task.browserRequestDisposition = 'STREAM_TAKEN';
    record('stream_taken', {acquisitionId: task.acquisitionId, requestId: event.requestId});
    task.binding = {tabId: source.tabId, sessionId: source.sessionId || null, debuggerEpoch: config.epoch,
      fetchRequestId: event.requestId, stream, networkId: event.networkId || null};
    const disposition = event.responseHeaders.find(x => x.name.toLowerCase() === 'content-disposition').value;
    const filename = /filename="([^"]+)"/.exec(disposition)[1];
    task.destination = task.acquisitionId + '-' + filename;
    await rpc('begin', {acquisitionId: task.acquisitionId, binding: task.binding, response,
      scenario: task.scenario, destination: task.destination});
    began = true; task.state = 'RECEIVING';
    let sequence = 0, eof = false;
    while (!eof) {
      const part = await send(source, 'IO.read', {handle: stream, size: 32768});
      let encoded = part.data;
      if (!part.base64Encoded) {
        let raw = ''; for (const n of new TextEncoder().encode(part.data)) raw += String.fromCharCode(n);
        encoded = btoa(raw);
      }
      if (encoded) await rpc('chunk', {acquisitionId: task.acquisitionId, sequence: sequence++, base64: encoded});
      record('stream_chunk', {acquisitionId: task.acquisitionId, sequence: sequence - 1, eof: !!part.eof});
      eof = !!part.eof;
    }
    await send(source, 'IO.close', {handle: stream}); stream = null;
    await send(source, 'Fetch.failRequest', {requestId: event.requestId, errorReason: 'Aborted'});
    task.browserRequestDisposition = 'CHROME_REQUEST_ABORTED_AFTER_TAKE';
    completing = true;
    task.completion = await rpc('complete', {acquisitionId: task.acquisitionId, eof: true});
    task.state = 'HISTORICAL_ACQUISITION_OBSERVED';
    record('acquisition_observed', {acquisitionId: task.acquisitionId, completion: task.completion});
  } catch (error) {
    task.state = task.browserRequestDisposition === 'PAUSED_NOT_TAKEN' ? 'TAKE_OUTCOME_UNKNOWN' :
      completing && !error.nativeRefusal ? 'OUTCOME_UNKNOWN' : 'FAILED_AFTER_TAKE';
    task.error = error.message;
    record('failure_after_take', {acquisitionId: task.acquisitionId, state: task.state, message: task.error});
    if (began && task.state !== 'OUTCOME_UNKNOWN') await rpc('abort', {acquisitionId: task.acquisitionId, reason: task.error}).catch(() => {});
    await send(source, 'Fetch.failRequest', {requestId: event.requestId, errorReason: 'Aborted'}).catch(() => {});
    task.browserRequestDisposition = task.state === 'TAKE_OUTCOME_UNKNOWN' ? 'TAKE_OUTCOME_UNKNOWN' : 'FAILED_NOT_NORMAL_CHROME_DOWNLOAD';
  } finally {
    if (stream) await send(source, 'IO.close', {handle: stream}).catch(() => {});
  }
}

chrome.debugger.onEvent.addListener((source, method, data) => {
  if (method === 'Fetch.requestPaused') onPaused(source, data).catch(error => record('handler_error', {message: error.message}));
});
chrome.debugger.onDetach.addListener((source, reason) => {
  record('debugger_detached', {source, reason}); sessions.delete(source.tabId);
});
chrome.downloads.onCreated.addListener(item => record('chrome_download_created', {item}));
chrome.downloads.onChanged.addListener(data => record('chrome_download_changed', {data}));

chrome.runtime.onMessage.addListener((message, sender, reply) => {
  if (sender.id !== chrome.runtime.id || sender.url !== chrome.runtime.getURL('control.html')) return false;
  (async () => {
    if (message.type === 'authorize') {
      if (message.takeoverConsent !== true || message.saveLocationConsent !== LAB.delivery) throw new Error('explicit_consent_required');
      const hello = await rpc('hello');
      const consent = await rpc('authorize', message);
      authorized = true; record('explicit_lab_consent', {nativePid: hello.pid, delivery: consent.delivery});
      return consent;
    }
    if (message.type === 'attach') {
      if (!authorized) throw new Error('takeover_disabled');
      await chrome.debugger.attach({tabId: message.tabId}, '1.3');
      sessions.set(message.tabId, {scenario: message.scenario, epoch: crypto.randomUUID()});
      await send({tabId: message.tabId}, 'Fetch.enable', {patterns: LAB.origins.flatMap(origin => [
        {urlPattern: origin + '/*', requestStage: 'Request'}, {urlPattern: origin + '/*', requestStage: 'Response'}])});
      record('attached', {tabId: message.tabId, scenario: message.scenario}); return {ok: true};
    }
    if (message.type === 'detach') {await chrome.debugger.detach({tabId: message.tabId}); return {ok: true};}
    if (message.type === 'disconnectNative') {port?.disconnect(); disconnected('explicit_native_disconnect'); return {ok: true};}
    if (message.type === 'snapshot') return {ok: true, events, acquisitions, authorized, native: port ? await rpc('status').catch(error => ({error: error.message})) : null,
      downloadItems: await chrome.downloads.search({})};
    if (message.type === 'tabs') return {ok: true, tabs: await chrome.tabs.query({})};
    throw new Error('control_command_not_allowed');
  })().then(reply, error => reply({ok: false, error: error.message}));
  return true;
});
